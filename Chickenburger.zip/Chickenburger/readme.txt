--Readme--

Hello, Merciful here!
Telamon and 007n7 were made with the amazing Zarla's template.
DIRECTIONS:
Double Click Telamon and 007n7 for options unique to their ghost, such as asking about their job, their day, and even letting them 'watch' what you're doing.
Right Click Telamon for SSP options, including getting links to resources like Zarla's template,changing your ghost, your shells, etc.


You can also pet them!
I wrote half of the dialogue when I was hungry. Sorry lol.

Updates are planned for them! Including adding their kids, 1x1x1x1 and C00lkidd. For fun I've included their placeholders but that's really it.

If you have no clue who these guys are, thats because they're loosely based off of Roblox avatars, specifically Forsaken's 007n7 and Telamon.
Loosely because it's actually my AU for them. *whistles*

Thank you so much for downloading this! It's my 1st ghost, so please don't laugh at my jumbled code... I am open to learning more about coding ghosts, and might think about making more in the future!

